slidenav
========

Facebook style slide navigation using Sencha Touch. 
